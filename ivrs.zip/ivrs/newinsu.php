 <html>
<head>

<script src="check.js" >
</script>

<?php
$custid=$_REQUEST['custid'];
//echo $custid;

$db=mysqli_connect('localhost','root','','ivrs');


$sql="SELECT curdate() as regdate,DATE_ADD(curdate(), INTERVAL 1 YEAR) as rendate";
$res=$db->query($sql);
$row=$res->fetch_object();

$fdate=$row->regdate;
$rendate=$row->rendate;

//echo $fdate.$rendate;

$sql="select customers.custid as custid,insuamt,regno,name,address,contno,vehname,vehdescr,chassino from customers,rto where( customers.custid=rto.custid and rto.custid='$custid')";
$res=$db->query($sql);
$row=$res->fetch_object();

$insuamt=$row->insuamt;
$regno=$row->regno;

?>

</head>

<body>

<table align=center cellspacing=5 cellpadding=5 border=1>
<caption><font color=blue><b>CUSTOMER DETAILS</b></font></caption>
<tr >
<th>Customer ID</th>
<td><?php echo $custid; ?> </td>
</tr>

<tr >
<th>Name</th>
<td><?php echo $row->name; ?> </td>
</tr>

<tr >
<th>Address</th>
<td><?php echo $row->address; ?> </td>
</tr>

<tr >
<th>Contact number</th>
<td><?php echo $row->contno; ?> </td>
</tr>

<tr >
<th>Vehicle Name</th>
<td><?php echo $row->vehname; ?> </td>
</tr>

<tr >
<th>Vehicle Description</th>
<td><?php echo $row->vehdescr; ?> </td>
</tr>

<tr >
<th>Chassis number</th>
<td><?php echo $row->chassino; ?> </td>
</tr>
</table>


<br><br>

<form name="f1" action="saveinsu.php" method="post" >

<table align=center cellspacing=5 cellpadding=5 border=1 width=80%>
<tr bgcolor=lightblue>
<th>Customer ID</th><th>Insurance Amount</th><th>Registration Date</th><th>Renewal Date</th><th>Registration Number</th>
</tr>

<tr>
<td>
<input type="text" name="custid" value=<?php echo $custid; ?> readonly />
</td>

<td>
<input type="text" name="insuamt" value=<?php echo $insuamt; ?> readonly />
</td>

<td>
<input type="text" name="fdate" value=<?php echo $fdate; ?> readonly />
</td>

<td>
<input type="text" name="rendate" value=<?php echo $rendate; ?> readonly />
</td>

<td>
<input type="text" name="regno" id="Reg No" value=<?php echo $regno; ?>  />
</td>

</tr>

<tr>
<td colspan=5 align=center>
<input style="background-color:honeydew; font-weight:bold; color:black;" type="submit" value=" REGISTER " onClick="return validate( f1 ) " />
</td>
</tr>
</table>

</form>

</body>



</html>