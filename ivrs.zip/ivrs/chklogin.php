 	<?php

	$shid=$_POST['shroom'];
	$uname=$_POST['uname'];
	$pwd=$_POST['pwd'];


	$sql="select * from showrooms where( shid='$shid' and uname='$uname' and pwd='$pwd')";

	$db=mysqli_connect('localhost','root','','ivrs');

	$res=$db->query( $sql);

	$flag;
	$shname;
	$shid;
	
	$row=$res->fetch_object();
	
	if( isset($row->shname) )
	{
	
	$flag=1;
	$shname=$row->shname;
	$shid=$row->shid;
	
	}
	else
	{
	$flag=0;

	}

	$db->close();


	if( $flag== 1 )
	{

	session_start();
	$_SESSION['shid']=$shid;
	header("Location: showroomhomepage.php?shname='$shname'");
	}
	else
	{
	header('Location: showroomlogin1.php');
	}

	?>