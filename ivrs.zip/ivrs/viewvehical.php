 	<html>

	<head>
	
	<?php

	session_start();
	$shid=$_SESSION['shid'];

	include_once('lib.php');
	
	$sql="select * from vehicals where shid='$shid'";
	
	$res=execute( $sql );


	?>

	
	</head>

	<body>

	<table align=center cellspacing=1 width=30% cellpadding=5 border=1>
	<tr bgcolor=pink>
	<th>Vehicle Name</th>
	<th>Remove</th>
	</tr>

	<?php
	while( $row=$res->fetch_object() )
	{
	?>
	<tr>
	<td><?php echo $row->vehname ?> </td>

	<td><a href=deletebike.php?sino=<?php echo $row->sino ?> >Delete</a></td>
	</tr>
	<?php
	}
	?>
	
	</table>
	</body>

	</html>