 <html>
<head>

<script src="check.js" >
</script>

<?php
$custid=$_REQUEST['custid'];
//echo $custid;

$db=mysqli_connect('localhost','root','','ivrs');


$sql="SELECT curdate() as regdate,DATE_ADD(curdate(), INTERVAL 15 YEAR) as rendate";
$res=$db->query($sql);
$row=$res->fetch_object();

$regdate=$row->regdate;
$rendate=$row->rendate;

//echo $regdate.$rendate;

$sql="select custid,name,address,contno,vehname,vehdescr,chassino,regamt from customers where custid='$custid'";
$res=$db->query($sql);
$row=$res->fetch_object();

$regamt=$row->regamt;

?>

</head>


<body>

<table align=center cellspacing=5 cellpadding=5 border=1>
<caption><font color=blue><b>CUSTOMER DETAILS</b></font></caption>
<tr >
<th>Customer ID</th>
<td><?php echo $custid; ?> </td>
</tr>

<tr >
<th>Name</th>
<td><?php echo $row->name; ?> </td>
</tr>

<tr >
<th>Address</th>
<td><?php echo $row->address; ?> </td>
</tr>

<tr >
<th>Contact number</th>
<td><?php echo $row->contno; ?> </td>
</tr>

<tr >
<th>Vehicle Name</th>
<td><?php echo $row->vehname; ?> </td>
</tr>

<tr >
<th>Vehicle Description</th>
<td><?php echo $row->vehdescr; ?> </td>
</tr>

<tr >
<th>Chassis number</th>
<td><?php echo $row->chassino; ?> </td>
</tr>
</table>


<br><br>

<form name="f1" action="saverto.php" method="post" >

<table align=center cellspacing=5 cellpadding=5 border=1 width=80%>
<tr bgcolor=lightblue>
<th>Customer ID</th><th>Registration Amount</th><th>Registration Date</th><th>Renewal Date</th><th>Regi No</th>
</tr>

<tr>
<td>
<input type="text" name="custid" value=<?php echo $custid; ?> readonly />
</td>

<td>
<input type="text" name="regamt" value=<?php echo $regamt; ?> readonly />
</td>

<td>
<input type="text" name="regdate" value=<?php echo $regdate; ?> readonly />
</td>

<td>
<input type="text" name="rendate" value=<?php echo $rendate; ?> readonly />
</td>

<td>
<input type="text" name="regno" id="Reg No" onKeyup="changeCase( this )" />
</td>

</tr>

<tr>
<td colspan=5 align=center>
<input style="background-color:honeydew; font-weight:bold; color:black;" type="submit" value=" REGISTER " onClick="return validate( f1 ) " />
</td>
</tr>
</table>

</form>

</body>


</html>