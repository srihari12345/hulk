 	<html>

	<head>

	<?php
	$shname=$_GET['shname'];

	session_start();
	$shid=$_SESSION['shid'];
	

	?>
	<style type="text/css">


	body{ background:url('img/pattern.png'); }
	td{
		text-align:center;
				
	}

	a{

		text-decoration:none;
		color:black;
		font-weight:bold;
	}

	a:hover{

		text-decoration:none;
		color:red;
		background-color: white;
		font-weight:bold;
	}		

	</style>


	<marquee>
	<b>WELCOME TO <font color=blue><?php echo $shname; ?> </font>SHOW ROOM</b>
	</marquee>
	</head>

	<body>

	
	<br><br>
	<table align=center width=100% cellspacing=5 bordercolor="purple" cellpadding=5 border="1">
	
	<tr bgcolor=lightblue>
	
	<td><a href=welcomesh.php target="ifr2">HOME</a></td>
	<td><a href=addnewentry.php target="ifr2" >ADD NEW ENTRY</a></td>

	<td><a href=vehicals.php target="ifr2" >VEHICALS</a></td>
	<td><a href=search.php target="ifr2">SEARCH</a></td>
	<td><a href=payment.php target="ifr2">PAYMENT</a></td>
	

	<td><a href=logout.php target="_parent">LOGOUT</a></td>
	</tr>
	</table>


	<iframe name="ifr2" src="welcomesh.php" width=100% height=100% frameborder=0>
	</iframe>
	
	</body>


	</html>