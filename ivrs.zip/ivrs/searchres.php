 	<html>
	<head>

	<script type="text/javascript" src="check.js" >
	</script>


	<?php

	$st=$_POST['searchtype'];	

	if( $st=="custid" )
	{
	$con="<b>Enter - Customer ID</b>";
	}
	else if( $st=="name")
	{
	$con="<b>Enter - Customer Name</b>";
	}
	else
	{
	$con="<b>Enter - Contact No</b>";
	}

	?>

	</head>


	<body>

	<center>

	<form name="f1" action="searchdisplay.php" method="post" >
	<input type="hidden" name="hst" value=<?php echo $st; ?> />

	<?php echo $con; ?>&nbsp;&nbsp;&nbsp;<input type="text" name="t1" id="Search Condition" />


	<input type="submit" value=" SEARCH " onClick="return validate(f1);" />
<br>
<br><br><br><br>
<img src=img/search.jpg>

	


	</form>
	</center>

	</body>

	</html>


	