 <html>

	<head>

	<script type="text/javascript" src="check.js" >
	</script>
		

	<?php
	
	$hst=$_POST['hst'];
	$con=$_POST['t1'];


	session_start();
	$shid=$_SESSION['shid'];
	
	
	if( $hst=="custid" )
	$sql="select * from customers where( custid='$con' and shid=$shid )";
	else if( $hst=="name" )
	$sql="select * from customers where( name='$con' and shid=$shid )";
	else
	$sql="select * from customers where( contno='$con' and shid=$shid )";

	
	$db=mysqli_connect('localhost','root','','ivrs');

	$res=$db->query( $sql );

	$row=$res->fetch_object();

	if( isset( $row->custid) )
	{
	$flag=1;
	}
	else
	{
	$flag=0;
	}
	
	
	

	if( $flag==0 )
	{
	echo "<center><b>Sorry Record Not Found !!</b></center>";
	return;
	}
	else
	{
	$res=$db->query( $sql );
	
	}
	
		
	?>


	</head>

	<body bgcolor=ivory>

<table width=52% bgcolor=white align=center cellspacing=5 cellpadding=5 border=1 bordercolor=black>
	<?php

	while( $row=$res->fetch_object() )
	{
	?>
	
	<tr>
	<td>
	Customer Id
	</td>
	<td>
	<?php echo $row->custid; ?>
	</td>
	</tr>

	<tr>
	<td>
	Name
	</td>
	<td>
	<?php echo $row->name; ?>
	</td>
	</tr>
        
        <tr>
	<td>
	Address
	</td>
	<td>
	<?php echo $row->address; ?></textarea>
	</td>
	</tr>

	<tr>
	<td>
	Mobile number
	</td>
	<td>
	<?php echo $row->contno; ?>
	</td>
	</tr>

	
	

	<tr>
	<td>
	Vehicle Name
	</td>
	<td>
	<?php echo $row->vehname; ?>
	</td>
	</tr>

	<tr>
	<td>
	Vehicle Description
	</td>
	<td>
	<?php echo $row->vehdescr; ?>
	</td>
	</tr>

	
	<tr>
	<td>
	Chassis number
	</td>
	<td>
	<?php echo $row->chassino; ?>
	</td>
	</tr>
        

	<tr>
	<td>
	Date Of Purchase
	</td>
	<td>
	<?php echo $row->dop; ?>
	</td>
	</tr>


	<tr>
	<td>
	Cost
	</td>
	<td>
	<?php echo $row->cost; ?>
	</td>
	</tr>


	<tr>
	<td>
	Scheme
	</td>
	<td>
	<?php echo $row->scheme; ?>
	</td>
	</tr>
        

	<tr>
	<td>
	Amount Paid
	</td>
	<td>
	<?php echo $row->amtpaid; ?>
	</td>
	</tr>


	<tr>
	<td>
	EMI Amount
	</td>
	<td>
	<?php echo $row->emiamt; ?>
	</td>
	</tr>


	<tr>
	<td>
	Number of Installments
	</td>
	<td>
	<?php echo $row->noinst; ?>
	</td>
	</tr>



	<tr>
	<td>
	Number of Installments Paid
	</td>
	<td>
	<?php echo $row->noinstp; ?>
	</td>
	</tr>

	<tr>
	<td>
	Registration Amount
	</td>
	<td>
	<?php echo $row->regamt; ?>
	</td>
	</tr>



	<tr>
	<td>
	Insurance Amount                     
	</td>
	<td>
	<?php echo $row->insuamt; ?>
	</td>
        </tr>

	<?php
	}

	$db->close();
	?>
	

	

	</body>

	</html>