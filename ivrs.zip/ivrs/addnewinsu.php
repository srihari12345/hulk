<html>
<head>
<script src="check.js" >
</script>


<?php
 
$db=mysqli_connect('localhost','root','','ivrs');
$sql="select custid from customers where custid not in(select custid from insu)";
$res=$db->query($sql);
?>
</head>

<body>

<br><br><br>

<form name="f1" action="newinsu.php" method="post" >

<hr size=8 color=#9997436 width=85%>
<br>

<center>

<b><font color=blue>Choose Customer ID :</font>

<select name="custid" id="Select Customer ID " >
<option value=#>  </option>
<?php
while( $row=$res->fetch_object() )
{
?>
<option value=<?php echo $row->custid; ?> > <?php echo $row->custid; ?> </option>

<?php
}
$db->close();
?> 

</select>

&nbsp;&nbsp;&nbsp;
<input type="submit" value=" SAVE " onClick="return validate(f1)" />
</center>

<br>
<hr size=8 color=#9997436 width=85%>
</form>
</body>
</html>