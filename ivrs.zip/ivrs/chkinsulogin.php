	<?php

	
	$uname=$_REQUEST['uname'];
	$pwd=$_REQUEST['pwd'];

	if( $uname=="insu" and $pwd=="insu" )
	{
	header("Location: insuhomepage.php");
	}
	else
	{
	echo "<center><b>Sorry Either user name or Password is Empty</b></center>";
	}


	?> 