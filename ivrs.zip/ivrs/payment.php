 	<html>

	<head>

	<center>
	<h2>Payment Form</h2>
	</center>

	<body>

	<center>

	<a href=addnewpayment.php>ADD NEW PAYMENT</a>
	<br><br>
	<a href=viewpaymentdet.php>VIEW PAYMENT DETAILS</a>
	

	</center>
	</body>

	</html>