 	<?php

	function execute( $sql )
	{

		$db=mysqli_connect('localhost','root','','ivrs');

		if( !$db )
		{

		die('could not connect'.mysqli_connect_error() );

		}


		$res=$db->query( $sql );

		if( !$res )
		{
		die(mysqli_error( $db ) );
		}

		return($res);
	}

	?>