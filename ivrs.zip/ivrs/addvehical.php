  	<?php
		
		session_start();
		$shid=$_SESSION['shid'];

		

		include_once('lib.php');


		if( isset($_POST['submit'] ))
		{
		
		$vname=$_POST['vehname'];

		$sql="select * from vehicals where( shid='$shid' and vehname='$vname')";

		$res=execute( $sql );

		$row=$res->fetch_object();

		if( isset( $row->vehname ) )
		{

		echo "<center><font color=red size=4>Sorry This Vehicle Name all ready Exists</font></center>";
		return;
		}


		$sql="insert into vehicals(shid,vehname) values('$shid','$vname')";

		$res=execute($sql);

		echo "<center><br><br><font color=blue size=4>Ok saved</font><br><br><a href=?>Return</a></center>";
		

		exit();	

		}



	?>


	<html>

	<head>
	<center>
	<h3><font color=maroon><u>ADD NEW VEHICLES FORM</u></font></h3>
	</center>

	<script src="check.js" >
	</script>

	</head>

	<center>
	<br><br>


	<form name="f1" action=? method="post" >
	<b>Enter Vehicle Name</b>&nbsp;&nbsp;

	<input onkeyup="changeCase(this)" type="text" size=50 name="vehname" id="Vehicle Name" />

	&nbsp;&nbsp;

	<input type="submit" name="submit" value="submit" onclick="return validate(f1)" />

	</center>

	</form>

	</body>

	</html>
	