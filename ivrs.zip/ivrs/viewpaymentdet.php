 <html>
<head>
<script type="text/javascript" src="check.js" >
</script>

<body>

<form action="showpayment.php" method="post" name="f1" >

<center>
<b>Enter Customer ID &nbsp;&nbsp;

<input type="text" name="tcustid" id="Customer ID" onKeyup="changeCase( this ) ">

&nbsp;&nbsp;

<input type="submit" value=" OK " onClick="return validate( f1 ) " />
</center>

</form>

</body>

</html>