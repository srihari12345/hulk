 <?php




$db=mysqli_connect('localhost','root','','ivrs');

$res=$db->query( $sql );

if( !$res )
{
echo "Error: in executing the statement !";
return;
}


$row=$res->fetch_object();

if( ! isset( $row->shid ) )
{
echo "<center><font color=red><b>Check the Current Password</b></font></center>";
return;
}


if( $npwd != $conpwd )
{

echo "<center><font color=red><b>Password Doesn't Match </b></font></center>";
return;

}




if( !$res )
{
echo "Error: in Updating the password !";
return;
}

echo "<center><br><font color=blue><b>OK Password Changed</b></font></center>";

?>