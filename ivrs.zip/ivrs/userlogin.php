 	<html>

	<head>

	<center>
	<font size=6 color=#895623 face="Algerian"><U>INTERNET BASED VEHICLE REGISTRATION SYSTEM</font>
	</center>
	


	<script type="text/javascript" src="check.js" >
	</script>
	</head>

	<body bgcolor="ivory" >
	
	<form name="f1" action="chkcustlogin.php" method="post" >

	<table bgcolor=white align=center cellspacing=5 cellpadding=5 border=1>
	
	<tr>
	<td>Customer ID</td>
	<td>
	<input type="text" id="Customer ID" name="custid" onkeyup="changeCase( this )" />
	</td>
	</tr>
	
	<tr>
	<td>Password</td>
	<td>
	<input type="password" id="Password" name="pwd" />
	</td>
	</tr>

	<tr>
	<td colspan=2 align=center >
	<input type="submit" value="Login" onClick="return validate( f1 )" />
	</td>
	</tr>

		
	</table>

	</form>


	</body>


	</html>