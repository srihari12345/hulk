 <html>
<head>
<script src="check.js" >
</script>


<script>

function fun1( t )
{

	if( t.custid.value=="" )
	{
		alert("Enter Customer ID");
		t.custid.focus();
		return;

	}	

	var path="showallrto.php?con=where( customers.custid=rto.custid and rto.custid='"+t.custid.value+"')";
	location.href=path;

}

function fun2( t )
{

	if( t.regno.value=="" )
	{
		alert("Enter Registration No");
		t.regno.focus();
		return;

	}	

	var path="showallrto.php?con=where( customers.custid=rto.custid and rto.regno='"+t.regno.value+"')";
	location.href=path;

}

</script>
</head>

<body>



<form name="f1" >

<table align=center cellspacing=10 cellpadding=5 >


<tr>
<td>
<b><font color=blue>
Search by Customer ID
</td>
<td>
<input type="text" name="custid" id="custid" onKeyup="changeCase( this )"  />
</td>
<td>
<input type="button" value=" DISPLAY " onClick="fun1(f1)" />
</td>
</tr>

<tr>
<td>
<b><font color=blue>
Search by Registration No 
</td>
<td>
<input type="text" name="regno" id="Regno" onKeyup="changeCase( this )" />
</td>
<td>
<input type="button" value=" DISPLAY " onClick="fun2(f1)"  />
</td>

</tr>


<tr>
<td colspan=3 align=center>
<b><a href="showallrto.php?con=where( customers.custid=rto.custid )"> <font color=red>SHOW ALL</font> </a>
</td>
</tr>
</table>
<center><img src=img/search.jpg></center>
</form>


</body>

</html>