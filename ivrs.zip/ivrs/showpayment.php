 <html>
<head>
<?php

session_start();
$shid=$_SESSION['shid'];


$custid=$_POST['tcustid'];

$sql="select custid,amtpaid,date_format(paydate,'%d-%M-%Y') as paydate from payments where ( custid='$custid' and shid='$shid')";
$db=mysqli_connect('localhost','root','','ivrs');
$res=$db->query( $sql );

$row=$res->fetch_object();

$sqls="select custid,scheme from customers where ( custid='$custid' and shid='$shid')";

$ress=$db->query( $sqls );
$rows=$ress->fetch_object();


if( ! isset( $rows->custid ) )
{
	echo "<center><b><font color=red>Sorry this Customer ID doesn't exists </font></center>";
	$db->close();
	return;
}



if( $rows->scheme=="FP" )
{

	echo "<center><b><font color=red>This customer has paid Full Amount </font></center>";
	$db->close();
	return;

}
else
{
$res=$db->query( $sql );

}



?>

<script type="text/javascript" src="check.js">
</script>

</head>

	<body bgcolor=ivory>

	<table bgcolor=white align=center width=70% cellspacing=5 cellpadding=5 border="1">
	<caption><b>Payment Details of Customer</b></caption>

	<tr bgcolor="yellow" >
	<th>Customer ID </th><th>Amount Paid</th><th>Pay Date</th>
	</tr>

	<?php
	while( ($row=$res->fetch_object()) )
	{
	?>

	<tr>
	<td><?php echo $row->custid; ?></td>
	<td><?php echo $row->amtpaid; ?></td>
	<td><?php echo $row->paydate; ?></td>
	</tr>
	
	<?php
	}
	$db->close();
	?>
	</table>

	</body>

</html>