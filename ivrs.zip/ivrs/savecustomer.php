 	<?php

	

	$shid=$_POST['shid'];
	$custid=$_POST['custid'];
	$name=$_POST['name'];
	$addr=$_POST['addr'];
	

	$cont=$_POST['cont'];
	$ofnum=$_POST['ofnum'];
	$resnum=$_POST['resnum'];
	$vehname=$_POST['vehname'];
	$vehdescr=$_POST['vehdescr'];
	$chassino=$_POST['chassino'];
	

	$dop=$_POST['dop'];
	$cost=$_POST['cost'];
	$scheme=$_POST['scheme'];
	$amtpaid=$_POST['amtpaid'];
	

	$emiamt=$_POST['emiamt'];
	$noinst=$_POST['noinst'];
	$noinstp=$_POST['noinstp'];
	$pwd=$_POST['pwd'];
	

	$regamt=$_POST['regamt'];
	$insuamt=$_POST['insuamt'];


	$db=mysqli_connect('localhost','root','','ivrs');

	$sql="insert into customers values($shid,'$custid','$name','$addr','$cont','$ofnum','$resnum','$vehname','$vehdescr','$chassino','$dop',$cost,'$scheme',$amtpaid,$emiamt,$noinst,$noinstp,'$pwd',$regamt,$insuamt)";
	
	$res=$db->query( $sql );

	echo "<center>OK SAVED<br><br><a href=addnewentry.php>BACK</a></center>";
	
	$db->close();
	
	?>


	