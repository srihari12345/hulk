 	<html>

	<head>


	</head>


	<body>

	<center>
	

	<a href=addvehical.php>ADD NEW </a>
	<br><br>
	<a href=viewvehical.php>VIEW EXISTING </a>
	
	



	</center>


	</body>

	</html>