 	<html>

	<head>
	<title>Add New Entry Form</title>

	<?php

	session_start();
	$shid=$_SESSION['shid'];


	$custid=$_POST['custid'];
	
	$db=mysqli_connect('localhost','root','challen','ivrs');

	$sql="select * from customers where ( custid='$custid' and shid=$shid )";
	$res=execute( $sql);

	$row=$res->fetch_object();

	if( isset( $row->custid) )
	{
	$flag=1;
	}
	else
	{
	$flag=0;
	}
	
	
	

	if( $flag==0 )
	{
	echo "<center><b>Sorry This customer ID does not exist !</b></center>";
	return;
	}
	
	
	?>
	
	<script type="text/javascript" src="check.js">
	</script>


	<script>

	function putAmount( f )
	{

		var i=f.scheme.selectedIndex;


		if( i==1 )
		{

			f.emiamt.value="0";
			
			
			f.noinst.value="0";
			
			
			f.noinstp.value="0";
			
			
		}
		else if( i==2 )
		{

			f.emiamt.value="";
			

			f.noinst.value="";
			
			
			f.noinstp.value="";
			
			


		}
		


	}
	</script>
	</head>


	<body bgcolor=ivory>


	<script >
	var oCalendarEn=new PopupCalendar("oCalendarEn");
	oCalendarEn.Init();
	</script>
      		
	<form name="f1" action="updatecustomer.php" method="post" >
	
	<table width=52% bgcolor=white align=center cellspacing=5 cellpadding=5 border=1 bordercolor=black>
	<caption><font color=red><b><u>Update Form</u></b></font></caption>
	

        <tr>
	<td>
	Customer ID
	</td>
	<td>
	<input type=text readonly name="custid" value=<?php echo $row->custid; ?> id="Name" onKeyup="changeCase(this)" />
	</td>
	</tr>

	<tr>
	<td>
	Name
	</td>
	<td>
	<input type=text name="name" value=<?php echo $row->name; ?> id="Name" onKeyup="changeCase(this)" />
	</td>
	</tr>
        
        <tr>
	<td>
	Address
	</td>
	<td>
	<textarea name="addr" id="Address" rows=6 onKeyUp="changeCase(this)" /><?php echo $row->address; ?></textarea>
	</td>
	</tr>

	<tr>
	<td>
	Contact No
	</td>
	<td>
	<input type="text" name="cont" id="Contact No" maxlength="10" value=<?php echo $row->contno; ?>  />
	</td>
	</tr>


	<tr>
	<td>
	Vehicle Name
	</td>
	<td>
	<input type=text name="vehname" id="Vehicle Name" value=<?php echo $row->vehname; ?> onKeyup="changeCase(this)" />
	</td>
	</tr>

	<tr>
	<td>
	Vehicle Description
	</td>
	<td>
	<textarea name="vehdescr" id="Vehicle Description" onKeyup="changeCase(this)" rows=6><?php echo $row->vehdescr; ?></textarea>
	</td>
	</tr>

	
	<tr>
	<td>
	Chassi No
	</td>
	<td>
	<input type=text name="chassino" id="Chassi No" value=<?php echo $row->chassino; ?> onKeyup="changeCase(this)" />
	</td>
	</tr>
        

	<tr>
	<td>
	Date Of Purchase
	</td>
	<td>
	<input type=text name="dop" value=<?php echo $row->dop; ?> id="Date Of Purchase" onClick="getDateString(this,oCalendarEn)" />
	</td>
	</tr>


	<tr>
	<td>
	Cost
	</td>
	<td>
	<input type=text name="cost" value=<?php echo $row->cost; ?> id="Cost" onKeypress="isDigit()" />
	</td>
	</tr>


	<tr>
	<td>
	Scheme
	</td>
	<td>
	<select name="scheme" id="Select the Scheme" onChange="putAmount( f1 )">
        <option value="aa">----Select Scheme----</option>

	<?php
	if( $row->scheme == "FP" )
	{
	?>
        <option value="FP" selected> FULL PAYMENT</option>
	<option value="INST"  > EMI PAYMENT</option>
	<?php
	}
	else
	{
	?>
	<option value="FP" > FULL PAYMENT</option>
        <option value="INST" selected > EMI PAYMENT</option>
	<?php
	}
	?>
	
	
        </select> 
	</td>
	</tr>
        

	<tr>
	<td>
	Amount Paid
	</td>
	<td>
	<input type=text name="amtpaid" id="Amount Paid" value=<?php echo $row->amtpaid; ?> onKeypress="isDigit()" />
	</td>
	</tr>


	<tr>
	<td>
	EMI Amount
	</td>
	<td>
	<input type=text name="emiamt" id="EMI Amount" value=<?php echo $row->emiamt; ?> onKeypress="isDigit()" />
	</td>
	</tr>


	<tr>
	<td>
	No Of Instalments
	</td>
	<td>
	<input type=text name="noinst" value=<?php echo $row->noinst; ?> id="No Of Instalments" onKeypress="isDigit()" />
	</td>
	</tr>



	<tr>
	<td>
	No Of Instalments Paid
	</td>
	<td>
	<input type=text name="noinstp" value=<?php echo $row->noinstp; ?> id="No Of Instalments Paid" onKeypress="isDigit()" />
	</td>
	</tr>




	<tr>
	<td>
	Registration Amount
	</td>
	<td>
	<input type=text name="regamt" id="Registration Amount" value=<?php echo $row->regamt; ?> onKeypress="isDigit()" />
	</td>
	</tr>



	<tr>
	<td>
	Insurance Amount                     
	</td>
	<td>
	<input type=text name="insuamt" value=<?php echo $row->insuamt; ?> id="Insurance Amount" onKeypress="isDigit()" />
	</td>
        </tr>


	<td colspan=2 align=center>
	<input type="submit" value="   UPDATE   " onClick="return validate(f1)" />
	</td>
	</tr>

	</table>
	</form>

	<?php
	$db->close();
	?>
	</body>

	
	</html>