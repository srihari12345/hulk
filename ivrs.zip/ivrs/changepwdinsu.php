 <html>
<head>

<?php
session_start();
$shid=$_SESSION['shid'];
?>

<script src="check.js" >
</script>


</head>


<body>

<form name="f1" action="savenewpwdinsu.php" method="post" >

<input type="hidden" value=<?php echo $shid; ?> name="shid" />
<table align=center cellspacing=5 cellpadding=5 border=1>

<tr>
<td>Enter Current Password</td>

<td>
<input type="password" name="cpwd" id="Current Password" />
</td>

</tr>


<tr>
<td>Enter New Password</td>

<td>
<input type="password" name="npwd" id="New Password" />
</td>

</tr>


<tr>
<td>Confirm Password</td>

<td>
<input type="password" name="conpwd" id="Confirm Password" />
</td>

</tr>



<tr>
<td align=center colspan=2 >
<input type="submit" value=" Change Password " onClick="return validate( f1 ) " />
</td>
</tr>

</table><br><br><br><br>
<center><img src=img/reset1.jpg></center>
</form>


</body>

</html>