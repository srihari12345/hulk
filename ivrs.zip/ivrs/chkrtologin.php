 	<?php

	
	$uname=$_REQUEST['uname'];
	$pwd=$_REQUEST['pwd'];

	if( $uname=="rto" and $pwd=="rto" )
	{
	header("Location: rtohomepage.php");
	}
	else
	{
	echo "<center><b>Sorry Either user name or Password is Empty</b></center>";
	}


	?>