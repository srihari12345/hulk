 	<html>
	
	<head>

	<?php
	include_once('header.php');
	?>

	<style type="text/css" >

	.st1{

		color:#235689;
		font-family:Poor Richard;
		font-size:20;
		font-weight:bold;
		background-color:honeydew;
		}

		a:hover{

		color:red;

		}
	

	</style>


	
	</head>


	<body bgcolor="lavender">

	<br>
	<hr size=5 width=80% color=#895623>
	
	<br><br><br>
	<div align=center>

	<a href=showroomlogin.php class="st1">SHOW ROOM</a>
	<br><br>
	<a href=rtologin.php class="st1">R.T.O</a>
	<br><br>
	<a href=insulogin.php class="st1">INSURANCE</a>

	<br><br>
	<a href=userlogin.php class="st1">CUSTOMERS</a>
	
	</div>
	</body>
	</html>