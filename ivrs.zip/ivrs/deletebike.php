 	<?php

	include_once('lib.php');

	$sino=$_REQUEST['sino'];

	$sql="delete from vehicals where sino=$sino";

	$res=execute( $sql );

	echo "<center><br><br><b>OK Deleted</b><br><br><a href=viewvehical.php>Return</a></center>";

	?>