 	<html>

	<head>

	<center>
	<font size=6 color=#895623 face="Algerian"><U>INTERNET BASED VEHICLE REGISTRATION SYSTEM</font></u>
	</center>
	

	<script type="text/javascript" src="check.js" >
	</script>
	</head>

	<body bgcolor=honeydew>
	
	<form name="f1" action="chkrtologin.php" method="post" >

	<table bgcolor=white align=center cellspacing=5 cellpadding=5 border=1>
	
	<tr>
	<td>User Name</td>
	<td>
	<input type="text" id="User Name" name="uname" />
	</td>
	</tr>
	
	<tr>
	<td>Password</td>
	<td>
	<input type="password" id="Password" name="pwd" />
	</td>
	</tr>

	<tr>
	<td colspan=2 align=center >
	<input type="submit" value="Login" onClick="return validate( f1 )" />
	</td>
	</tr>

		
	</table>
<br><br><br><br><br><br><br><br><br>
<marquee><font color=blue size=25>Welcome to <font color=red face="Algerian"><b>R</b></font>egional <font color=red face="Algerian"><b>T</b></font>ransport <font color=red face="Algerian"><b>O</b></font>ffice</font></marquee>
	</form>


	</body>


	</html>