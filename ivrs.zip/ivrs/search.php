 	<html>

	<head>

	<script type="text/javascript" src="check.js" >
	</script>
	
	<center>
	<h2><u>Searching Form</u></h2>
	</center>

	</head>

	<body>

	<br><br>

	<form name="f1" action="searchres.php" method="post" >

	<center>

	<b>Select Search Condition : </b>

	<select id="Select Search Condition" name="searchtype" >

	<option value=#> </option>
	<option value="custid">By Customer ID </option>
	<option value="name">By Name </option>
	<option value="contno">By ContactNo </option>
		
	</select>

	&nbsp;&nbsp;<input type="submit" value=" GO " onClick="return validate(f1);" />

	</center>
	
	</form>
	
	</body>

	</html>

