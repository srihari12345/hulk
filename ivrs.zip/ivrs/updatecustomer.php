 	<?php

	
	$custid=$_POST['custid'];
	$name=$_POST['name'];
	$addr=$_POST['addr'];
	

	$cont=$_POST['cont'];
	$vehname=$_POST['vehname'];
	$vehdescr=$_POST['vehdescr'];
	$chassino=$_POST['chassino'];
	

	$dop=$_POST['dop'];
	$cost=$_POST['cost'];
	$scheme=$_POST['scheme'];
	$amtpaid=$_POST['amtpaid'];
	

	$emiamt=$_POST['emiamt'];
	$noinst=$_POST['noinst'];
	$noinstp=$_POST['noinstp'];
	
	$regamt=$_POST['regamt'];
	$insuamt=$_POST['insuamt'];


	$db=mysqli_connect('localhost','root','','ivrs');

	$sql="update customers set name='$name',address='$addr',contno='$cont',vehname='$vehname',vehdescr='$vehdescr',chassino='$chassino',dop='$dop',cost=$cost,scheme='$scheme',amtpaid=$amtpaid,emiamt=$emiamt,noinst=$noinst,noinstp=$noinstp,regamt=$regamt,insuamt=$insuamt where custid='$custid' ";
	
	$res=$db->query( $sql );

	echo "<center>OK UPDATED<br><br><a href=getcustid.php>RETURN</a></center>";
	
	?>