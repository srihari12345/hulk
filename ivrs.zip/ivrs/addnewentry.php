	<html>

	<head>
	<title>Add New Entry Form</title>

	<?php

	session_start();
	$shid=$_SESSION['shid'];
	

	include_once('lib.php');

	

	$sql="select count(*)+1 as noc from customers where shid=$shid";
	
	$res=execute( $sql);

	if( !$res  )
	{ 
	echo "Sorry could not run the query !";
	exit();
	}

	$row=$res->fetch_object();

	$csid="SH".$shid."CS".$row->noc;

	
	$sql="select * from vehicals where shid='$shid'";
	$res=execute( $sql);

	
	
	?>
	
	<script type="text/javascript" src="check.js">
	</script>


	<script>

	function putAmount( f )
	{

		var i=f.scheme.selectedIndex;


		if( i==1 )
		{

			f.emiamt.value="0";
			
			
			f.noinst.value="0";
			
			
			f.noinstp.value="0";
			
			f.amtpaid.value=f.cost.value;
		}
		else if( i==2 )
		{

			f.emiamt.value="";
			

			f.noinst.value="";
			
			
			f.noinstp.value="";
			
			


		}
		


	}
	</script>
	</head>


	<body background="img/pattern.png" >


	<script >
	var oCalendarEn=new PopupCalendar("oCalendarEn");
	oCalendarEn.Init();
	</script>
      		
	<form name="f1" action="savecustomer.php" method="post" >
	
	<table width=52%  align=center cellspacing=5 cellpadding=5 border=1 bordercolor=black>
	<caption>Add New Entry Form</caption>
	<tr>
	<td>
	Showroom Id
	</td>
	<td>
	<input type=text name="shid" id="Showroom Id" readonly value=<?php echo $shid; ?> />
	</td>
	</tr>

        <tr>
	<td>
	Customer Id
	</td>
	<td>
	<input type=text name="custid" id="Customer Id" value=<?php echo $csid; ?> onKeyup="changeCase(this)" />
	</td>
	</tr>

	<tr>
	<td>
	Name
	</td>
	<td>
	<input type=text name="name" id="Name" maxlength=40 onKeyup="changeCase(this)" />
	</td>
	</tr>
        
        <tr>
	<td>
	Address
	</td>
	<td>
	<textarea name="addr" id="Address" rows=6 onKeyUp="changeCase(this)" /></textarea>
	</td>
	</tr>

	<tr>
	<td>
	Mobile number
	</td>
	<td>
	<input type=text name="cont" id="Mobile number" value="+91" maxlength=13 onKeypress="isDigit()" />
	</td>
	</tr>

	<tr>
	<td>
	Office number
	</td>
	<td>
	<input type=text name="ofnum" id="Office number" maxlength=13 onKeypress="isDigit()" />
	</td>
	</tr>

	<tr>
	<td>
	Residence number
	</td>
	<td>
	<input type=text name="resnum" id="Residence number" maxlength=13 onKeypress="isDigit()" />
	</td>
	</tr>
	

	<tr>
	<td>
	Vehicle Name
	</td>
	<td>


	<select name="vehname" id=" Choose Vehicle Name" >

	<?php
	while( $row=$res->fetch_object() )
	{
	?>

	<option value='<?php echo $row->vehname ?>' ><?php echo $row->vehname ?></option>
	
	<?php
	}
	?>
	
	</select>
	</td>
	</tr>

	<tr>
	<td>
	Vehicle Description
	</td>
	<td>
	<textarea name="vehdescr" id="Vehicle Description" onKeyup="changeCase(this)" rows=6></textarea>
	</td>
	</tr>

	
	<tr>
	<td>
	Chassis number
	</td>
	<td>
	<input maxlength=17 type=text name="chassino" id="Chassi No" onKeyup="changeCase(this)" />
	</td>
	</tr>
        

	<tr>
	<td>
	Date Of Purchase
	</td>
	<td>
	<input type=date name="dop" id="Date Of Purchase"  />
	</td>
	</tr>


	<tr>
	<td>
	Cost
	</td>
	<td>
	<input type=text name="cost" id="Cost" maxlength=7 onKeypress="isDigit()" />
	</td>
	</tr>


	<tr>
	<td>
	Scheme
	</td>
	<td>
	<select name="scheme" id="Select the Scheme" onChange="putAmount( f1 )">
        <option value="aa">----Select Scheme----</option>
        <option value="FP"> FULL PAYMENT</option>
        <option value="INST"> EMI PAYMENT</option>
        </select> 
	</td>
	</tr>
        

	<tr>
	<td>
	Amount Paid
	</td>
	<td>
	<input type=text name="amtpaid" id="Amount Paid" onKeypress="isDigit()" />
	</td>
	</tr>


	<tr>
	<td>
	EMI Amount
	</td>
	<td>
	<input type=text name="emiamt" id="EMI Amount" onKeypress="isDigit()" />
	</td>
	</tr>


	<tr>
	<td>
	Number of Installments
	</td>
	<td>
	<input type=text name="noinst" id="No Of Installments" onKeypress="isDigit()" />
	</td>
	</tr>



	<tr>
	<td>
	Number of Installments Paid
	</td>
	<td>
	<input type=text name="noinstp" id="No Of Installments Paid" onKeypress="isDigit()" />
	</td>
	</tr>



	<tr>
	<td>
	Password
	</td>
	<td>
	<input type=password name="pwd" maxlength=20 id="Password" />
	</td>
	</tr>


	<tr>
	<td>
	Registration Amount
	</td>
	<td>
	<input type=text name="regamt" id="Registration Amount" onKeypress="isDigit()" />
	</td>
	</tr>



	<tr>
	<td>
	Insurance Amount                     
	</td>
	<td>
	<input type=text name="insuamt" id="Insurance Amount" onKeypress="isDigit()" />
	</td>
        </tr>


	<td colspan=2 align=center>
	<input type="submit" value="   SUBMIT   " onClick="return validate(f1)" />
	</td>
	</tr>

	</table>
	</form>
	</body>

	
	</html>