 <html>
<head>
<font color="black" size="6"><center>WELCOME TO INSURANCE OFFICE</center></font><br>
<style type="text/css" >

a{
	text-decoration:none;
	color:black;
}

a:hover{
	background-color:black;
	color:white;
}
</style>
</head>

<body>

<table width=100% align=center cellspacing=5 cellpadding=5 bordercolor="purple" border=1>
<tr bgcolor=ivory>
<th><a href=welcomeinsu.php target="ifr2">HOME</a></th>
<th><a href=addnewinsu.php target="ifr2">NEW INSURANCE</a></th>
<th><a href=searchinsu.php target=ifr2>SEARCH</a></th>
<th><a href=logoutinsu.php target="_parent" >LOGOUT</a></th>
</tr>
</table>

<iframe name="ifr2" src="welcomeinsu.php" frameborder=0 framealign=center width=100% height=100%>
</iframe>
</body>

</html>

