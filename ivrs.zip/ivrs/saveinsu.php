 <?php
$custid=$_REQUEST['custid'];
$regno=$_REQUEST['regno'];
$fdate=$_REQUEST['fdate'];
$insuamt=$_REQUEST['insuamt'];
$rendate=$_REQUEST['rendate'];


$db=mysqli_connect('localhost','root','','ivrs');




$sql="insert into insu values('$custid','$regno',$insuamt,'$fdate','$rendate')";
$res=$db->query($sql);

echo "<br><br><br><center><b>Ok Insured<br><br><a href=addnewinsu.php>BACK</a></center>";

?>