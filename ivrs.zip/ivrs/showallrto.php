 <html>

<head>

<?php

$con=$_REQUEST['con'];

$db=mysqli_connect('localhost','root','','ivrs');
$sql="select rto.custid as custid,name,address,contno,vehname,vehdescr,chassino,regno from customers,rto ".$con;



$res=$db->query($sql);

?>
</head>


<body>

<table align=center cellspacing=5 cellpadding=5 border=1 width=100%>
<tr bgcolor=yellow>
<th>Customer ID</th><th>Name</th><th>Address</th><th>Contact Number</th><th>Vehicle name</th><th>Vechicle Description</th><th>Chassis number</th><th>Registration Number</th>
</tr>

<?php
while( $row=$res->fetch_object() )
{
?>

<tr>
<td><?php echo $row->custid; ?> </td>
<td><?php echo $row->name; ?> </td>
<td><?php echo $row->address; ?> </td>
<td><?php echo $row->contno; ?> </td>
<td><?php echo $row->vehname; ?> </td>
<td><?php echo $row->vehdescr; ?> </td>
<td><?php echo $row->chassino; ?> </td>
<td><?php echo $row->regno; ?> </td>
</tr>

<?php
}
$db->close();

?>

</table>
</body>
</html>