 		<html>
	<head>
	<?php
	
	
	$db=mysqli_connect('localhost','root','','ivrs');
	$sql="select shid,shname from showrooms order by shname";
	$res=$db->query( $sql );
	

	?>
	<script type="text/javascript" src="check.js" >

	</script>

	<center>
	<font size=6 color=#895623 face="Algerian"><U>INTERNET BASED VEHICLE REGISTRATION SYSTEM</font>
	</center>
	</head>

	<body >


	<br>
	<form name="f1" action="chklogin.php" method="post"  >
	
	<table align="right" bgcolor=white border=1 cellspacing=5 cellpadding=5>
	<tr>
	<td>
	<b>Show room</b>
	</td>
	<td>
	<select name="shroom" id="Select Show room" >
	<option>--------Select showroom---------</option>
	<?php
	while( $row=$res->fetch_object() )
	{
	?>
	
	<option value=<?php echo $row->shid;?> ><?php echo $row->shname; ?> </option>

	<?php
	}
	?>
	

	</select>
	</td>	
	</tr>

	<tr>
	<td><b>User name</td>
	<td><input type="text" name="uname" /></td>
	</tr>

	<tr>
	<td><b>Password</td>
	<td><input type="password" name="pwd" /></td>
	</tr>

	<tr>
	<td colspan=2 align=center>
	<input type="submit" value=" LOGIN " onClick="return validate(f1)" />
	</td>
	</tr>

	<tr>
	<td align=center colspan=2>
	<font color=red><b>Either User name or password is wrong</b></font>
	</td>

	</tr>

	</table>
	
	</form>

	</body>
	
	<div align=left>
	<img src="img/anigif.gif" />
	</div>
	
	
	</html>