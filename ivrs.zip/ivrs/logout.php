  
	<html>


	<head>
	
	
<br><br><br><br><br><br><br><br>
	<center><img src="img/namaste_welcome.gif" height=100 width=100 >
	<h1> Thank YOU </h1>
	
	<a href=index.php>Relogin</a>

	</center>
	</head>

	<body>

	</body>


	</html>