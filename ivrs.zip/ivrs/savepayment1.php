 <?php

session_start();
$shid=$_SESSION['shid'];

$custid=$_POST['custid'];

$emiamt=$_POST['emiamt'];
$pdate=$_POST['pdate'];


$db=mysqli_connect('localhost','root','','ivrs');
$sql="insert into payments values($shid,'$custid',$emiamt,'$pdate')";
$res=$db->query($sql);


$sql="update customers set noinstp=noinstp+1,amtpaid=amtpaid+$emiamt where custid='$custid'";
$res=$db->query($sql);


echo "<br><br><br><b><center>OK Payment Updated<br><br><a href=index.php>BACK</a></b></center>";

$db->close();

?>