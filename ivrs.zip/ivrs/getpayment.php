 <html>
<head>
<?php

session_start();
$shid=$_SESSION['shid'];


$custid=$_POST['tcustid'];

$sql="select * from customers where ( custid='$custid' and shid='$shid')";
$db=mysqli_connect('localhost','root','','ivrs');
$res=$db->query( $sql );

$row=$res->fetch_object();

$flag=0;
if( isset( $row->custid ) )
{
$flag=1;
}

if( $flag==0 )
{
	echo "<center><b><font color=red>Sorry this customer ID doesn't exist</font></center>";
	$db->close();
	return;
}

if( $row->scheme=="FP" )
{

	echo "<center><b><font color=red>This customer has paid Full Amount </font></center>";
	$db->close();
	return;

}


?>

<script type="text/javascript" src="check.js">
</script>

</head>

	<body bgcolor=ivory>

	<script >
	var oCalendarEn=new PopupCalendar("oCalendarEn");
	oCalendarEn.Init();
	</script>

	<form name="f1" action="savepayment.php" method="post">

	<table bgcolor=white align=center cellspacing=5 cellpadding=5 border=1>
	<caption><h3><font color=blue>Customer Details..</font></h3></caption>
	<tr>
	<td>
	Customer Id
	</td>

	<td>
	<input type="text" readonly name="custid" value=<?php echo $row->custid; ?> />
	</td>
	</tr>

	<tr>
	<td>
	Name
	</td>

	<td>
	<?php echo $row->name; ?>
	</td>
	</tr>

	<tr>
	<td>
	Cost
	</td>

	<td>
	<?php echo $row->cost; ?>
	</td>
	</tr>


	<tr>
	<td>
	Amount Paid
	</td>

	<td>
	<?php echo $row->amtpaid; ?>
	</td>
	</tr>

	<tr>
	<td>
	Emi Amount
	</td>

	<td>
	<input name="emiamt" type="text" value=<?php echo $row->emiamt; ?> id="Emi Amount" onKeypress="isDigit()" />
	</td>
	</tr>

	<tr>
	<td>
	No of Installments
	</td>

	<td>
	<?php echo $row->noinst; ?>
	</td>
	</tr>

	<tr>
	<td>
	No of Installments Paid
	</td>

	<td>
	<?php echo $row->noinstp; ?>
	</td>
	</tr>


	<tr>
	<td>
	Select Pay Date
	</td>

	<td>
	<input type="text" id="Pay Date" name="pdate" onClick="getDateString(this,oCalendarEn)" />
	</td>
	</tr>

	<tr>
	<td colspan=2 align=center>
	<input type="submit" value=" SAVE " onClick="return validate( f1 ) " />
	</td>
	</tr>
	
	</table>

	</form>


	<?php

	$db->close();

	?>

	</body>

</html>