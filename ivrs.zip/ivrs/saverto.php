 <?php
$custid=$_REQUEST['custid'];
$regno=$_REQUEST['regno'];
$regdate=$_REQUEST['regdate'];
$regamt=$_REQUEST['regamt'];
$rendate=$_REQUEST['rendate'];


$db=mysqli_connect('localhost','root','','ivrs');


$sql="select * from rto where regno='$regno'";
$res=$db->query($sql);
$row=$res->fetch_object();

$flag;
if( isset($row->custid) )
{
$flag=1;
}
else
{
$flag=0;
}

if( $flag==1 )
{

echo "<center><font color=red><b>Sorry This Registration number is used</b></font>";
$db->close();
return;


}

$sql="insert into rto values('$custid','$regno','$regdate',$regamt,'$rendate')";
$res=$db->query($sql);

echo "<br><br><br><center><b>Ok Registered<br><br><a href=addnewreg.php>BACK</a></center>";

?>